package org.gribov.socialnet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocialnetApplicationTests {

	@Test
	void contextLoads() {
	}

}
