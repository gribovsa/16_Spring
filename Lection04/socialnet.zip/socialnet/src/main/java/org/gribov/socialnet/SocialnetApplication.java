package org.gribov.socialnet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialnetApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocialnetApplication.class, args);
	}

}
