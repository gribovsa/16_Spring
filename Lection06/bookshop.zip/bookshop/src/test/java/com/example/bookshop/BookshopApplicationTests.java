package com.example.bookshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
